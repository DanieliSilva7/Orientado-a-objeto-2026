/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.unipar.supermercado;

/**
 *
 * @author danieli70300
 */
public class Supermercado {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
