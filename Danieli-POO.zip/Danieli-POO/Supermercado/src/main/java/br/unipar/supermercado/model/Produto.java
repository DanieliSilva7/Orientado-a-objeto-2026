/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.supermercado.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author danieli70300
 */
public class Produto {
    public class Produto {
    private String nome;
    private double preco;
    private int qtdEstoque;

    public Produto(String nome, double preco, int qtdEstoque) {
        this.nome = nome;
        this.preco = preco;
        this.qtdEstoque = qtdEstoque;
    }
    // Getters e Setters...
}

public class ItemPedido {
    private Produto produto;
    private int quantidade;

    public ItemPedido(Produto produto, int quantidade) {
        this.produto = produto;
        this.quantidade = quantidade;
    }
    // Getters e Setters...
}

public class Pedido {
    private List<ItemPedido> itens;
    private String formaPagamento; // Dinheiro, Cheque ou Cartão

    public Pedido(String formaPagamento) {
        this.itens = new ArrayList<>();
        this.formaPagamento = formaPagamento;
    }
    
    public void adicionarItem(ItemPedido item) {
        this.itens.add(item);
    }
}
}
