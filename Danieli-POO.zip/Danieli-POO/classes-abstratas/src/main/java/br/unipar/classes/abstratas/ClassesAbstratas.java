/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.unipar.classes.abstratas;
import br.unipar.classes.abstratas.domain.Gato;

/**
 *
 * @author danieli70300
 */
public class ClassesAbstratas {

    public static void main(String[] args) {
        Gato gato = new Gato();
        gato.setNome("Frajola");
        gato.emitirSom();
        gato.amamentar();
    }
}
