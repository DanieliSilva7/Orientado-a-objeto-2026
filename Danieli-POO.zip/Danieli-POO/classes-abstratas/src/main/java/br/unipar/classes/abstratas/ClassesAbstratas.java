/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.unipar.classes.abstratas;

/**
 *
 * @author danieli70300
 */
public class ClassesAbstratas {

    public static void main(String[] args) {
        private String nome;
    }
}
