/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.classes.abstratas.domain;

/**
 *
 * @author danieli70300
 */
public class Gato extends Mamifero{

   

    @Override
    public void amamentar() {
        System.out.println("Miaaaaaauu");

    }
       
}
