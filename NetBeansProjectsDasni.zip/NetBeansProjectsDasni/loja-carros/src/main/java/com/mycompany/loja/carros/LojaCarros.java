/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loja.carros;

import javax.swing.JOptionPane;

import com.mycompany.loja.carros.model.Carro;
import com.mycompany.loja.carros.model.Marca;
import com.mycompany.loja.carros.model.Modelo;


/**
 *
 * @author danieli70300
 */
public class LojaCarros {

    public static void main(String[] args) {
        
        Marca marca = new Marca();
        marca.setCnpj("54654665");
        marca.setId(1);
        marca.setNomeFantasia("BMW");
        marca.setRazaoSocial("tantantan");
        
        Modelo modelo = new Modelo();
        modelo.setId(1);
        modelo.setNome("M3");
        modelo.setVelocidadeMaxima(22.0);
        
        Carro carro= new Carro();
        carro.setAno(2025);
        carro.setCor("Cinza");
        carro.setNrChassi("kd321321");
        carro.setMarca(marca);
        carro.setModelo(modelo);
        
        JOptionPane.showMessageDialog(null,carro.toString());
   
    }
}

